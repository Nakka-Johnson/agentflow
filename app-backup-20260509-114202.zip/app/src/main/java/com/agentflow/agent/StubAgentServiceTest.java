package main.java.com.agentflow.agent;

import static org.assertj.core.api.Assertions.assertThat;
import org.junit.jupiter.api.Test;

import com.nakka.agentflow.agent.StubAgentService;
import com.nakka.agentflow.api.dto.AgentRunRequest;
import com.nakka.agentflow.api.dto.AgentRunResponse;

class StubAgentServiceTest {

    private final StubAgentService service = new StubAgentService();

    @Test
    void respondsWithStubMessageContainingTheQuery() {
        AgentRunRequest request = new AgentRunRequest("How do I configure Redis?", null);

        AgentRunResponse response = service.run(request);

        assertThat(response.response()).contains("How do I configure Redis?");
        assertThat(response.response()).contains("stub agent");
    }

    @Test
    void generatesConversationIdWhenNoneProvided() {
        AgentRunRequest request = new AgentRunRequest("any query", null);

        AgentRunResponse response = service.run(request);

        assertThat(response.conversationId()).isNotBlank();
    }

    @Test
    void preservesProvidedConversationId() {
        AgentRunRequest request = new AgentRunRequest("any query", "conv-12345");

        AgentRunResponse response = service.run(request);

        assertThat(response.conversationId()).isEqualTo("conv-12345");
    }

    @Test
    void emptyToolCallsForStub() {
        AgentRunRequest request = new AgentRunRequest("any query", null);

        AgentRunResponse response = service.run(request);

        assertThat(response.toolCalls()).isEmpty();
    }
}